/**
 * Author:
 * GTID:
 * GT Email:
 */

#pragma once
void *recv_thread(void*socket_desc);
int main(int argc, char *argv[]);

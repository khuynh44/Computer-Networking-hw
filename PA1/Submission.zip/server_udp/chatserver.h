/**
 * Author:
 * GTID:
 * GT Email:
 */

#pragma once
typedef struct {
    int used;
    struct sockaddr_in client;
} Client;

int main(int argc, char *argv[]);

/**
 * Author:
 * GTID:
 * GT Email:
 */

#pragma once
void trim(char* arr, int length);
void *recv_thread(void*socket_desc);
int main(int argc, char *argv[]);
